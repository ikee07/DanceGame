from selenium import webdriver
import time
import pyautogui

# Set up the Selenium WebDriver
driver = webdriver.Firefox()

# Open the website
driver.get("https://the-internet.herokuapp.com/digest_auth")


time.sleep(2)  # Adjust the sleep time as needed

# Use pyautogui to type the username and password and press Enter
pyautogui.write("admin")
pyautogui.press("tab")
pyautogui.write("admin")
pyautogui.press("enter")

time.sleep(10)

driver.quit()
