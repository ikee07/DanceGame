# -*- coding: utf-8 -*-
"""
Created on Sun Nov 26 21:14:36 2023

@author: ikbel
"""

import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX
from pmdarima import auto_arima

# Read the CSV file for the data of 3 months
data = pd.read_csv("Covid19_3months.csv", parse_dates=['Date'], index_col='Date', low_memory=False)
print("---- 3 Months ----")
print(data.head())
print()

# # Read The CSV File for the full 12months
# data_all = pd.read_csv("COVID19_12months.csv", parse_dates=['Date'], index_col='Date', low_memory=False)
# print("---- 12 Months ----")
# print(data_all.head())
# print()

# # Print the column names to inspect
# print("Column names in data:")
# print(data.columns)

# Auto ARIMA for model order selection
model_order = auto_arima(data['Total_cases'], seasonal=True, m=7)
order = model_order.get_params()['order']
seasonal_order = model_order.get_params()['seasonal_order']

# Fit SARIMA model
model = SARIMAX(data['Total_cases'], order=order, seasonal_order=seasonal_order)
results = model.fit(disp=False)

# Forecast for 6 months data
forecast_steps = len(data)
forecast = results.get_forecast(steps=forecast_steps)
pred_mean = forecast.predicted_mean
conf_int = forecast.conf_int()

# # Forecast for 12 months data
# forecast_steps_all = len(data_all)
# forecast_all = results.get_forecast(steps=forecast_steps_all)
# pred_mean_all = forecast_all.predicted_mean
# conf_int_all = forecast_all.conf_int()



# Plotting
plt.figure(figsize=(12, 6))

# Regression Graph of 6 months
plt.subplot(1, 2, 1)
plt.title('Covid Cases 01/10/2020-06/30/2020')
plt.plot(data.index, data['Total_cases'], label="Actual Data")
plt.plot(data.index, pred_mean, color='red', label="predection")
plt.fill_between(data.index, conf_int.iloc[:, 0], conf_int.iloc[:, 1], color='pink', alpha=0.3, label="Confidence Interval")
plt.legend()


# plt.subplot(1, 2, 2)
# plt.title('Covid Cases 01/10/2020-1/30/2021')
# plt.plot(data_all.index, data_all['Total_cases'], label="Actual Data")
# plt.plot(data_all.index, pred_mean_all, color='red', label="predection")
# plt.fill_between(data_all.index, conf_int_all.iloc[:, 0], conf_int_all.iloc[:, 1], color='pink', alpha=0.3, label="Confidence Interval")
# plt.legend()

plt.tight_layout()
plt.show()
